# i-perpus

Repository i-perpus<br>
<br>
Tugas Mata Kuliah Rekayasa perangkat lunak Smst 5<br>
Kelas SA03 2017<br>
Poilteknik STMI JAKARTA 2020<br>
KELOMPOK :<br>
Ahmad Fajar Islami<br>
Ibnu Syina<br>
Bunga Smara<br>
Ghina<br>
Ihsan<br>
<br>
<br>
Aplikasi Perpustakaan Online ini dibuat dengan menggunakan PHP 7<br>

Install:<br>
Download dan ubah nama folder menjadi i-perpustakaan<br>
Install Database dalam folder database<br>
